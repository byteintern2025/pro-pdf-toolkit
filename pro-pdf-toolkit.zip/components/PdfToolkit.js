import React, { useState } from 'react'
import { PDFDocument, StandardFonts } from 'pdf-lib'
import JSZip from 'jszip'
import { saveAs } from 'file-saver'

export default function PdfToolkit() {
  const [log, setLog] = useState('Ready')
  function appendLog(t) { setLog(prev => `${new Date().toLocaleTimeString()}: ${t}\n` + prev) }
  const toArrayBuffer = (file) => new Promise((res, rej) => {
    const r = new FileReader()
    r.onload = () => res(r.result)
    r.onerror = rej
    r.readAsArrayBuffer(file)
  })

  const mergePdfs = async (files) => {
    try {
      appendLog('Merging ' + files.length + ' PDFs')
      const merged = await PDFDocument.create()
      for (const f of files) {
        const buf = await toArrayBuffer(f)
        const doc = await PDFDocument.load(buf)
        const copied = await merged.copyPages(doc, doc.getPageIndices())
        copied.forEach(p => merged.addPage(p))
      }
      const out = await merged.save()
      saveAs(new Blob([out], { type: 'application/pdf' }), 'merged.pdf')
      appendLog('Merged saved as merged.pdf')
    } catch (e) { appendLog('Merge error: ' + e.message) }
  }

  const splitPdf = async (file, from, to) => {
    try {
      appendLog(`Splitting ${file.name} pages ${from}-${to}`)
      const buf = await toArrayBuffer(file)
      const src = await PDFDocument.load(buf)
      const out = await PDFDocument.create()
      const total = src.getPageCount()
      const fromIdx = Math.max(1, from)
      const toIdx = Math.min(total, to)
      const copied = await out.copyPages(src, Array.from({length: toIdx - fromIdx + 1}, (_,i) => fromIdx -1 + i))
      copied.forEach(p => out.addPage(p))
      const outBuf = await out.save()
      saveAs(new Blob([outBuf], { type: 'application/pdf' }), `${file.name.replace(/\.[^.]+$/, '')}_${from}-${to}.pdf`)
      appendLog('Split saved')
    } catch (e) { appendLog('Split error: ' + e.message) }
  }

  const imagesToPdf = async (files) => {
    try {
      appendLog(`Converting ${files.length} images to PDF`)
      const pdf = await PDFDocument.create()
      for (const f of files) {
        const buf = await toArrayBuffer(f)
        const type = f.type
        let img
        if (type === 'image/png') img = await pdf.embedPng(buf)
        else img = await pdf.embedJpg(buf)
        const page = pdf.addPage([img.width, img.height])
        page.drawImage(img, { x: 0, y: 0, width: img.width, height: img.height })
      }
      const out = await pdf.save()
      saveAs(new Blob([out], { type: 'application/pdf' }), 'images.pdf')
      appendLog('Images converted')
    } catch (e) { appendLog('Images->PDF error: ' + e.message) }
  }

  const addTocPage = async (basePdfFile, entries) => {
    try {
      appendLog('Adding TOC page...')
      const baseBuf = await toArrayBuffer(basePdfFile)
      const src = await PDFDocument.load(baseBuf)
      const out = await PDFDocument.create()
      const copied = await out.copyPages(src, src.getPageIndices())
      copied.forEach(p => out.addPage(p))
      const toc = out.addPage([595.28, 841.89])
      const font = await out.embedFont(StandardFonts.Helvetica)
      const fontSize = 14
      toc.drawText('Table of Contents', { x: 50, y: 780, size: 20, font })
      for (let i = 0; i < entries.length; i++) {
        const e = entries[i]
        const y = 740 - i * 22
        toc.drawText(`${i+1}. ${e.title} — page ${e.page}`, { x: 60, y, size: fontSize, font })
        const destPageIndex = e.page - 1
        if (destPageIndex >= 0 && destPageIndex < out.getPageCount()) {
          toc.addLinkAnnotation({ x: 60, y: y - 2, width: 400, height: 18, page: out.getPage(destPageIndex) })
        }
      }
      const pages = out.getPages()
      const tocPage = pages[pages.length - 1]
      const final = await PDFDocument.create()
      const [tocCopy] = await final.copyPages(out, [out.getPageCount() - 1])
      final.addPage(tocCopy)
      const restIdxs = Array.from({length: out.getPageCount() - 1}, (_,i) => i)
      const rest = await final.copyPages(out, restIdxs)
      rest.forEach(p => final.addPage(p))
      const outBuf = await final.save()
      saveAs(new Blob([outBuf], { type: 'application/pdf' }), `${basePdfFile.name.replace(/\.[^.]+$/, '')}_with_TOC.pdf`)
      appendLog('TOC added and file saved')
    } catch (e) { appendLog('TOC error: ' + e.message) }
  }

  const extractZip = async (file, password) => {
    try {
      appendLog('Reading zip...')
      const buf = await toArrayBuffer(file)
      const zip = new JSZip()
      const content = await zip.loadAsync(buf)
      const names = Object.keys(content.files)
      appendLog('Zip contains: ' + names.join(', '))
      const outZip = new JSZip()
      for (const name of names) {
        if (content.files[name].dir) continue
        const fileData = await content.files[name].async('uint8array')
        outZip.file(name, fileData)
      }
      const blob = await outZip.generateAsync({ type: 'blob' })
      saveAs(blob, file.name.replace(/\.zip$/, '') + '_extracted.zip')
      appendLog('Extracted and saved (repacked)')
    } catch (e) {
      appendLog('Zip extract error: ' + e.message + '. If zip is encrypted, provide password or unzip locally.')
    }
  }

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <h2 className="text-2xl font-semibold mb-4">Pro PDF Toolkit — Client-side (No keys)</h2>

      <section className="mb-6 p-4 bg-white rounded shadow">
        <h3 className="font-medium">Merge PDFs</h3>
        <input type="file" accept="application/pdf" multiple onChange={e => mergePdfs(Array.from(e.target.files))} className="mt-2" />
        <p className="text-sm text-gray-500 mt-2">Select multiple PDF files and they'll be merged in order selected.</p>
      </section>

      <section className="mb-6 p-4 bg-white rounded shadow">
        <h3 className="font-medium">Split PDF (extract pages)</h3>
        <input id="splitFile" type="file" accept="application/pdf" className="mt-2" />
        <div className="flex gap-2 mt-2">
          <input id="from" type="number" placeholder="from (1)" className="border p-1" />
          <input id="to" type="number" placeholder="to" className="border p-1" />
          <button className="px-3 py-1 bg-blue-600 text-white rounded" onClick={() => {
            const f = document.getElementById('splitFile').files[0];
            const from = parseInt(document.getElementById('from').value || '1')
            const to = parseInt(document.getElementById('to').value || '1')
            if (!f) return appendLog('Pick a PDF first')
            splitPdf(f, from, to)
          }}>Split</button>
        </div>
      </section>

      <section className="mb-6 p-4 bg-white rounded shadow">
        <h3 className="font-medium">Images → PDF</h3>
        <input type="file" accept="image/*" multiple onChange={e => imagesToPdf(Array.from(e.target.files))} className="mt-2" />
      </section>

      <section className="mb-6 p-4 bg-white rounded shadow">
        <h3 className="font-medium">Add Table of Contents (TOC) / simple bookmarks</h3>
        <input id="tocFile" type="file" accept="application/pdf" className="mt-2" />
        <p className="text-sm text-gray-500">Add entries below (title and page number). Page numbers must match the base PDF pages after processing.</p>
        <div id="tocEntries" className="mt-2 space-y-2">
          <input placeholder="Title|page (e.g. Chapter 1|2)" id="toc0" className="w-full border p-1" />
        </div>
        <div className="flex gap-2 mt-2">
          <button className="px-3 py-1 bg-green-600 text-white rounded" onClick={() => {
            const idx = document.querySelectorAll('#tocEntries input').length
            const inp = document.createElement('input')
            inp.placeholder = 'Title|page (e.g. Chapter 1|2)'
            inp.className = 'w-full border p-1'
            inp.id = 'toc' + idx
            document.getElementById('tocEntries').appendChild(inp)
          }}>Add entry</button>
          <button className="px-3 py-1 bg-blue-600 text-white rounded" onClick={() => {
            const f = document.getElementById('tocFile').files[0]
            if (!f) return appendLog('Pick a PDF first')
            const nodes = document.querySelectorAll('#tocEntries input')
            const entries = Array.from(nodes).map(n => {
              const v = n.value || ''
              const [title, page] = v.split('|').map(s => s && s.trim())
              return { title: title || 'Untitled', page: parseInt(page || '1') }
            })
            addTocPage(f, entries)
          }}>Add TOC</button>
        </div>
      </section>

      <section className="mb-6 p-4 bg-white rounded shadow">
        <h3 className="font-medium">Zip extract (no password cracking)</h3>
        <input id="zipFile" type="file" accept=".zip" className="mt-2" />
        <div className="flex gap-2 mt-2">
          <input id="zpwd" placeholder="(optional) password if you have it" className="border p-1" />
          <button className="px-3 py-1 bg-orange-600 text-white rounded" onClick={() => {
            const f = document.getElementById('zipFile').files[0]
            const pwd = document.getElementById('zpwd').value
            if (!f) return appendLog('Pick a zip first')
            if (!pwd) extractZip(f)
            else appendLog('JSZip in-browser cannot handle encrypted zips automatically — unzip locally with password or use a trusted desktop tool.')
          }}>Extract (repack)</button>
        </div>
        <p className="text-xs text-gray-500 mt-2">**Note:** This app will <strong>not</strong> attempt to guess or crack passwords. Provide a password to unzip locally and then use tools to upload contents.</p>
      </section>

      <section className="mt-6 p-4 bg-white rounded shadow">
        <h3 className="font-medium">Diagnostics / Log</h3>
        <pre className="text-xs whitespace-pre-wrap max-h-48 overflow-auto bg-gray-800 text-white p-3 rounded">{log}</pre>
      </section>

    </div>
  )
}
