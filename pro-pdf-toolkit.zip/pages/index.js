import dynamic from 'next/dynamic'
import Head from 'next/head'
const PdfToolkit = dynamic(() => import('../components/PdfToolkit'), { ssr: false })

export default function Home() {
  return (
    <>
      <Head>
        <title>Pro PDF Toolkit</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>
      <main>
        <PdfToolkit />
      </main>
    </>
  )
}
